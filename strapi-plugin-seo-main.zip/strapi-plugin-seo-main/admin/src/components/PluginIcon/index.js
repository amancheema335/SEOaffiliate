/**
 *
 * PluginIcon
 *
 */

import React from 'react';
import Search from '@strapi/icons/Search';

const PluginIcon = () => <Search />;

export default PluginIcon;
