export { default as getTrad } from './getTrad';
