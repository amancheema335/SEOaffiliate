'use strict';

const seo = require('./seo');
const settings = require('./settings');

module.exports = {
  seo,
  settings
};
