module.exports = {
  seo: require('./seo'),
  settings: require('./settings'),
};
